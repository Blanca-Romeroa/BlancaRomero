import { useEffect, useRef, useState } from "react";

export default function AboutSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Imagen de la doctora */}
          <div className={`transition-all duration-800 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'}`}>
            <div className="relative">
              <div className="aspect-[4/5] bg-gradient-to-br from-brown-yellow/20 to-dark-vanilla/30 rounded-2xl shadow-elegant overflow-hidden">
                <div className="w-full h-full bg-gradient-to-br from-khaki/40 to-pale-silver/60 flex items-center justify-center">
                  <div className="text-center text-brown-yellow/60">
                    <div className="w-24 h-24 mx-auto mb-4 bg-brown-yellow/20 rounded-full flex items-center justify-center">
                      <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                      </svg>
                    </div>
                    <p className="font-taviraj text-lg">Dra. Blanca Romero</p>
                  </div>
                </div>
              </div>
              {/* Elemento decorativo */}
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-brown-yellow/20 rounded-full blur-xl"></div>
            </div>
          </div>

          {/* Contenido de texto */}
          <div className={`transition-all duration-800 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}>
            <div className="space-y-6">
              <h2 className="font-taviraj text-4xl lg:text-5xl font-bold text-text-primary leading-tight">
                Dra. Blanca Romero
              </h2>
              
              <div className="w-20 h-1 bg-brown-yellow rounded-full"></div>
              
              <p className="font-quicksand text-lg text-text-secondary leading-relaxed">
                Especialista en medicina estética y regenerativa, la Dra. Blanca Romero combina 
                la ciencia avanzada con un enfoque profundamente humano y personalizado.
              </p>
              
              <p className="font-quicksand text-lg text-text-secondary leading-relaxed">
                Su objetivo es restaurar y potenciar la belleza natural de cada paciente, 
                ayudándolos a verse y sentirse mejor a través de tratamientos innovadores 
                que respetan la individualidad de cada persona.
              </p>
              
              <p className="font-quicksand text-lg text-text-secondary leading-relaxed">
                Con años de experiencia y una formación continua en las últimas técnicas 
                de medicina regenerativa, la Dra. Romero ofrece un enfoque integral que 
                une la ciencia, la estética y el bienestar.
              </p>
              
              {/* Valores destacados */}
              <div className="grid grid-cols-3 gap-4 pt-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-brown-yellow/20 rounded-full flex items-center justify-center mx-auto mb-2">
                    <svg className="w-6 h-6 text-brown-yellow" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                  </div>
                  <p className="font-taviraj font-semibold text-brown-yellow">Confianza</p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-brown-yellow/20 rounded-full flex items-center justify-center mx-auto mb-2">
                    <svg className="w-6 h-6 text-brown-yellow" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                  </div>
                  <p className="font-taviraj font-semibold text-brown-yellow">Calidad</p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-brown-yellow/20 rounded-full flex items-center justify-center mx-auto mb-2">
                    <svg className="w-6 h-6 text-brown-yellow" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
                    </svg>
                  </div>
                  <p className="font-taviraj font-semibold text-brown-yellow">Empatía</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}