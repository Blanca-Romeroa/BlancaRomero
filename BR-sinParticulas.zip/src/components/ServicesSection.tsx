import { useEffect, useRef, useState } from "react";

const services = [
  {
    title: "Rejuvenecimiento facial",
    description: "Tratamientos avanzados para restaurar la juventud y luminosidad natural de tu rostro.",
    icon: (
      <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
      </svg>
    )
  },
  {
    title: "Terapia regenerativa",
    description: "Técnicas innovadoras que estimulan la regeneración celular para resultados naturales y duraderos.",
    icon: (
      <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
      </svg>
    )
  },
  {
    title: "Nutrición avanzada",
    description: "Planes nutricionales personalizados que complementan tus tratamientos estéticos desde adentro.",
    icon: (
      <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.94-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
      </svg>
    )
  },
  {
    title: "Cuidado corporal",
    description: "Tratamientos integrales para el cuidado y embellecimiento de todo tu cuerpo.",
    icon: (
      <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 2c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm9 7h-6v13h-2v-6h-2v6H9V9H3V7h18v2z"/>
      </svg>
    )
  },
  {
    title: "Armonización facial",
    description: "Técnicas especializadas para equilibrar y realzar la armonía natural de tus facciones.",
    icon: (
      <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
        <path d="M9 11H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2zm2-7h-1V2h-2v2H8V2H6v2H5c-1.1 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11z"/>
      </svg>
    )
  },
  {
    title: "Bienestar integral",
    description: "Enfoque holístico que combina tratamientos estéticos con el cuidado de tu bienestar general.",
    icon: (
      <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
        <path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
      </svg>
    )
  }
];

export default function ServicesSection() {
  const [visibleCards, setVisibleCards] = useState<number[]>([]);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const cardIndex = parseInt(entry.target.getAttribute('data-index') || '0');
            setVisibleCards(prev => [...prev, cardIndex]);
          }
        });
      },
      { threshold: 0.2 }
    );

    const cards = document.querySelectorAll('.service-card');
    cards.forEach(card => observer.observe(card));

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-white-coffee to-pale-silver/50">
      <div className="max-w-7xl mx-auto">
        {/* Encabezado de la sección */}
        <div className="text-center mb-16">
          <h2 className="font-taviraj text-4xl lg:text-5xl font-bold text-text-primary mb-6">
            Nuestros Servicios
          </h2>
          <div className="w-24 h-1 bg-brown-yellow rounded-full mx-auto mb-6"></div>
          <p className="font-quicksand text-xl text-text-secondary max-w-3xl mx-auto leading-relaxed">
            Descubre nuestra gama completa de tratamientos diseñados para realzar tu belleza natural 
            y promover tu bienestar integral
          </p>
        </div>

        {/* Grid de servicios */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              data-index={index}
              className={`service-card group bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-500 hover:scale-105 hover-glow cursor-pointer ${
                visibleCards.includes(index) 
                  ? 'opacity-100 translate-y-0' 
                  : 'opacity-0 translate-y-8'
              }`}
              style={{ 
                transitionDelay: `${index * 100}ms`,
                border: '1px solid hsl(var(--khaki) / 0.2)'
              }}
            >
              {/* Icono */}
              <div className="w-16 h-16 bg-gradient-to-br from-brown-yellow to-dark-vanilla rounded-full flex items-center justify-center mb-6 text-white group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>

              {/* Título */}
              <h3 className="font-taviraj text-2xl font-semibold text-text-primary mb-4 group-hover:text-brown-yellow transition-colors duration-300">
                {service.title}
              </h3>

              {/* Descripción */}
              <p className="font-quicksand text-text-secondary leading-relaxed">
                {service.description}
              </p>

              {/* Elemento decorativo */}
              <div className="mt-6 w-12 h-1 bg-gradient-to-r from-brown-yellow to-dark-vanilla rounded-full group-hover:w-20 transition-all duration-300"></div>
            </div>
          ))}
        </div>

        {/* Llamada a la acción */}
        <div className="text-center mt-16">
          <p className="font-quicksand text-lg text-text-secondary mb-6">
            ¿Listo para comenzar tu transformación?
          </p>
          <button className="bg-brown-yellow hover:bg-dark-vanilla text-white font-quicksand font-semibold px-8 py-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
            Consulta personalizada
          </button>
        </div>
      </div>
    </section>
  );
}