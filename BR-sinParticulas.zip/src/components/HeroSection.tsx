import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

export default function HeroSection() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Fondo con gradiente animado */}
      <div className="absolute inset-0 gradient-subtle">
        <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-brown-yellow/10 animate-float"></div>
      </div>
      
      {/* Contenido principal */}
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className={`transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {/* Título principal */}
          <h1 className="font-pinyon text-5xl sm:text-6xl lg:text-7xl text-text-primary mb-6 leading-tight">
            Belleza regenerativa,
            <br />
            <span className="text-brown-yellow">bienestar integral</span>
          </h1>
          
          {/* Subtítulo */}
          <p className="font-taviraj text-xl sm:text-2xl lg:text-3xl text-text-secondary mb-8 max-w-3xl mx-auto leading-relaxed">
            Medicina estética y regenerativa con un enfoque humano y personalizado
          </p>
          
          {/* Botón CTA */}
          <div className={`transition-all duration-1000 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <Button 
              size="lg" 
              className="bg-brown-yellow hover:bg-dark-vanilla text-white font-quicksand font-semibold px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
            >
              Agendar cita
            </Button>
          </div>
        </div>
      </div>
      
      {/* Elementos decorativos */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-brown-yellow/20 rounded-full blur-xl animate-float"></div>
      <div className="absolute bottom-20 right-10 w-32 h-32 bg-dark-vanilla/20 rounded-full blur-xl animate-float" style={{animationDelay: '1s'}}></div>
      <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-khaki/30 rounded-full blur-lg animate-float" style={{animationDelay: '2s'}}></div>
    </section>
  );
}